/*
 * Sequence.cpp
 *
 *  Created on: 09/feb/2016
 *      Author: samuele
 */

#include "Sequence.h"

Sequence::Sequence() {
	this->setIndexFile(0);
}

Sequence::~Sequence() {
	// TODO Auto-generated destructor stub
}
