/*
 * Chono.cpp
 *
 *  Created on: 15/set/2016
 *      Author: samuele
 */

#include "Chrono.h"

Chrono::Chrono() {
	// TODO Auto-generated constructor stub

}

Chrono::~Chrono() {
	// TODO Auto-generated destructor stub
}

